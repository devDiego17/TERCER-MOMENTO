package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("**** Droguerias DP, sistema de inventario ****");

        String [] medicamentos = new String[5];
        int [] cantidadMedicamentos = new int[5];

        for (int i = 0; i < 5; i++){


            System.out.print("Ingresa el nombre del medicamento que vas agregar al inevntario: ");
            medicamentos[i]= teclado.nextLine().toLowerCase();

            System.out.print("Ingrese la cantidad de ese medicamento que va a ingresar a el inventario: ");
            cantidadMedicamentos[i]=Integer.parseInt(teclado.nextLine());
        }
        int opcion;
        do {
            System.out.println("\nA continuación, elija una opción:");
            System.out.println("""
                    1. Buscar un medicamento por nombre y mostrar su cantidad.
                    2. Mostrar el medicamento con mayor cantidad en stock.
                    3. Mostrar medicamentos con menos de 10 unidades.
                    4. Salir del programa.
                    """);

            System.out.print("Opción: ");
            opcion = Integer.parseInt(teclado.nextLine());

            switch (opcion) {
                case 1 :
                    System.out.print("Ingrese el nombre del medicamento que desea buscar: ");
                    String nombreBuscado = teclado.nextLine();
                    boolean encontrado = false;

                    for (int i = 0; i < medicamentos.length; i++) {
                        if (medicamentos[i].equalsIgnoreCase(nombreBuscado)) {
                            System.out.println("Cantidad de " + medicamentos[i] + ": " + cantidadMedicamentos[i]);
                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado) {
                        System.out.println("El medicamento no está en el inventario.");
                    }
                    break;

                case 2:
                    int mayorCantidad = cantidadMedicamentos[0];
                    String medicamentoMayor = medicamentos[0];

                    for (int i = 1; i < medicamentos.length; i++) {
                        if (cantidadMedicamentos[i] > mayorCantidad) {
                            mayorCantidad = cantidadMedicamentos[i];
                            medicamentoMayor = medicamentos[i];
                        }
                    }
                    System.out.println("El medicamento con mayor cantidad es: " + medicamentoMayor + " con " + mayorCantidad + " unidades.");
                    break;

                case 3 :
                    System.out.println("Medicamentos con menos de 10 unidades:");
                    for (int i = 0; i < medicamentos.length; i++) {
                        if (cantidadMedicamentos[i] < 10) {
                            System.out.println("- " + medicamentos[i] + ": " + cantidadMedicamentos[i] + " unidades");
                        }
                    }
                    break;

                case 4:
                    System.out.println("Saliendo del programa. ¡Gracias por usar el sistema!");
                    break;

                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 4);
        teclado.close();
    }
}