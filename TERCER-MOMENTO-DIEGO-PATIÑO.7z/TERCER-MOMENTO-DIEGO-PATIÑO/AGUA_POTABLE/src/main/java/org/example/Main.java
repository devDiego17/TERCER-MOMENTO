package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("**** Encuesta de agua potable EPM ****");

        Scanner teclado = new Scanner(System.in);
        int siTieneAcceso = 0;
        int noTieneAcceso = 0;

        for (int i = 0; i < 10; i++){

            System.out.print("""
                    
                    A continuacion ingrese si usted tiene 
                    acceso a agua potable en su hogar
                    
                    escriba (si/no) en su respuesta:\s """);
            String tieneAccesoAguaPotable = teclado.nextLine().toLowerCase();

            /*pude haberlo hecho con un boolean pero queria que
            la respuesta quedara en español (si o no)
            y no en ingles (true o false) */

            if (tieneAccesoAguaPotable.equals("si")){
                siTieneAcceso++;
            } else if (tieneAccesoAguaPotable.equals("no")) {
                noTieneAcceso++;
            }else {
                System.out.println("Respuesta invalida");
            }

        }
        System.out.printf("""
                la cantidad de casa con acceso 
                al agua potable es de %d
                y la cantidad de hogares sin acceso
                a agua potable es de %d
                """,siTieneAcceso,noTieneAcceso);

    }
}